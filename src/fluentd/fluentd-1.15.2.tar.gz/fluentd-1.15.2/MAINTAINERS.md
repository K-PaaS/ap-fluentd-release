# Fluentd Maintainers

- [Naotoshi Seo](https://github.com/sonots), [ZOZO Technologies](https://tech.zozo.com/en/)
- [Okkez](https://github.com/okkez)
- [Hiroshi Hatake](https://github.com/cosmo0920), [Calyptia](https://calyptia.com/)
- [Masahiro Nakagawa](https://github.com/repeatedly), [Treasure Data](https://www.treasuredata.com/)
- [Satoshi Tagomori](https://github.com/tagomoris), [Treasure Data](https://www.treasuredata.com/)
- [Eduardo Silva](https://github.com/edsiper), [Calyptia](https://calyptia/)
- [Fujimoto Seiji](https://github.com/fujimots), [ClearCode](https://www.clear-code.com/)
- [Takuro Ashie](https://github.com/ashie), [ClearCode](https://www.clear-code.com/)
- [Kentaro Hayashi](https://github.com/kenhys), [ClearCode](https://www.clear-code.com/)
