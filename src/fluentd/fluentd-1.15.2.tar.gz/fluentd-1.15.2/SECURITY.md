# Security Policy

## Supported Versions

| Version   | Supported          |
| -------   | ------------------ |
| 1.14.x    | :white_check_mark: |
| <= 1.13.x | :x:                |

## Reporting a Vulnerability

Please contact to current active maintainers. (in alphabetical order)

* ashie@clear-code.com
* fujimoto@clear-code.com
* hatake@calyptia.com
* hayashi@clear-code.com

